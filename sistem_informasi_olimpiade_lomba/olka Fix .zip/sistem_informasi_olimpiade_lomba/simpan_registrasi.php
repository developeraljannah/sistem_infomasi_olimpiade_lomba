<?php

// koneksi database
include 'koneksi.php';

// menangkap data yang di kirim dari form
$id_kompetisi = mysqli_real_escape_string($koneksi, $_POST['id_kompetisi']);
$nisn = mysqli_real_escape_string($koneksi, $_POST['nisn']);
$id_gurupendamping = mysqli_real_escape_string($koneksi, $_POST['id_gurupendamping']);
$tanggal = date('D/M/Y');
$waktu = date('H:i:s');

// menginput data ke database
mysqli_query($koneksi, "INSERT INTO tb_registrasi(id_kompetisi, nisn, id_gurupendamping, tanggal_reg, waktu_reg) VALUES ('$id_kompetisi','$nisn','$id_gurupendamping','$tanggal','$waktu')");
echo "<script>alert('Data registrasi telah berhasil tersimpan');window.location='index.php'</script>";
