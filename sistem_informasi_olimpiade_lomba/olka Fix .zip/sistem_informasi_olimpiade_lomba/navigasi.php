<!-- Navigation -->
<a class="menu-toggle rounded" href="#">
    <i class="fas fa-bars"></i>
  </a>
  <nav id="sidebar-wrapper">
    <ul class="sidebar-nav">
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="#page-top">Beranda</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="#fitur">Fitur</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="#registrasi">Registrasi</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="#loginjuri">Login Juri</a>
      </li>
      <li class="sidebar-nav-item">
        <a class="js-scroll-trigger" href="#contact">Contact</a>
      </li>
    </ul>
  </nav>