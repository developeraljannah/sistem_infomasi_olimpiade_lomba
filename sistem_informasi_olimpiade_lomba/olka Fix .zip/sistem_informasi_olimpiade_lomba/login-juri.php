<!-- Proses Login -->
<?php
if (isset($_POST['login'])) {
    include "koneksi.php";
    // $user dan $pass adalah variabel
    $emailjuri = mysqli_real_escape_string($koneksi, $_POST['email_juri']);
    $passwordjuri = mysqli_real_escape_string($koneksi, $_POST['password_juri']);


    $login_juri = mysqli_query($koneksi, "SELECT * FROM tb_juri WHERE email_juri = '$emailjuri' AND password_juri = '$passwordjuri'");
    $get_juri = mysqli_fetch_array($login_juri);
    $id_juri = $get_juri['id_juri'];
    $nama_juri = $get_juri['nama_juri'];
    $cek_juri = mysqli_num_rows($login_juri);

    // kondisi jika ada user ada
    if ($cek_juri > 0) {
        // get session dan pesan
        echo "<script>alert('Login berhasil');window.location='input-nilai.php'</script>";
        $_SESSION['id_juri'] = $id_juri;
        $_SESSION['nama_juri'] = $nama_juri;
        $_SESSION['kondisi'] = "login";
    } else {
        // jika gagal alias user yidak ditemukan
        echo "<script>alert('Email dan Password tidak sesuai');window.location='index.php'</script>";
    }
}
?>