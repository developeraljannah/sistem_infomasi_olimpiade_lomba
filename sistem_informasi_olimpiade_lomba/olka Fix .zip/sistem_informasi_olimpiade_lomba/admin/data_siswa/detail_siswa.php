<?php
session_start();
if ($_SESSION['kondisi'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Sistem Informasi Olimpiade, Lomba dan Kompetensi Al Azhar</title>
    <link href="../css/styles.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand" href="index.html">Admin Panel</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#"><i class="fas fa-bars"></i></button>

        <!-- Navbar-->
        <ul class="navbar-nav ml-auto mr-0 mr-md-3 my-2 my-md-0">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="logout.php">Logout</a>
                </div>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <!-- Menu Navigasi -->
                <?php include "../navigasi_in.php"; ?>
                <div class="sb-sidenav-footer">
                    <div class="small">Nama Admin :</div>
                    <p class="text-gray-800">
                        <!-- Page Heading -->
                        <?php
                        $username = $_SESSION['username'];
                        echo $username;
                        ?>
                    </p>
                </div>
            </nav>
        </div>

        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <h1 class="mt-4">Detail Data Siswa</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Halaman untuk menampilkan informasi detail Siswa</li>
                    </ol>

                    <!-- konten detail siswa -->
                    <?php
                    include '../../koneksi.php';
                    $ambil_nisn = $_GET['nisn'];

                    $data = mysqli_query($koneksi, "SELECT tb_siswa.nisn, tb_siswa.nis, tb_siswa.nama_siswa, tb_siswa.id_kelas, tb_kelas.nama_kelas, tb_siswa.tempat_lahir, tb_siswa.tanggal_lahir, tb_siswa.asal_sd, tb_siswa.foto FROM tb_siswa, tb_kelas WHERE tb_siswa.id_kelas = tb_kelas.id_kelas AND tb_siswa.nisn = '$ambil_nisn'");
                    while ($d = mysqli_fetch_array($data)) {
                        $nisn = $d['nisn'];
                        $nis = $d['nis'];
                        $namasiswa = $d['nama_siswa'];
                        $namakelas = $d['nama_kelas'];
                        $tempatlahir = $d['tempat_lahir'];
                        $tanggallahir = $d['tanggal_lahir'];
                        $asalsd = $d['asal_sd'];
                    ?>

                        <div class="media">
                            <?php
                            $tampil_foto = $d['foto'];
                            if (is_file("foto_siswa/" . $tampil_foto)) {
                                $cetak_foto = $tampil_foto;
                            } else {
                                $cetak_foto = 'foto-default.jpg';
                            }
                            ?>
                            <img class="mr-3" src="foto_siswa/<?php echo $cetak_foto; ?>" width="250px" height="350px">
                            <div class="media-body">
                                <div class="card">
                                    <div class="card-header bg-primary text-white">
                                        Detail Info Siswa
                                    </div>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">NISN : <?php echo $nisn; ?></li>
                                        <li class="list-group-item">NIS : <?php echo $nis ?></li>
                                        <li class="list-group-item">Nama Siswa : <?php echo $namasiswa; ?></li>
                                        <li class="list-group-item">Nama Kelas : <?php echo $namakelas; ?></li>
                                        <li class="list-group-item">Tempat Lahir : <?php echo $tempatlahir; ?></li>
                                        <li class="list-group-item">Tanggal Lahir : <?php echo $tanggallahir; ?></li>
                                        <li class="list-group-item">Asal : <?php echo $asalsd; ?></li>
                                    </ul>
                                </div>
                            </div>

                        </div>

                    <?php } ?>
                    <br>
                    <a href="lihat_siswa.php" class="btn btn-success">kembali</a>
                    <!-- Penutup konten detail siswa -->

                </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Your Website 2020</div>
                        <div>
                            <a href="#">Privacy Policy</a>
                            &middot;
                            <a href="#">Terms &amp; Conditions</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="../js/scripts.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
    <script src="../assets/demo/datatables-demo.js"></script>
</body>

</html>