        
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">NAVIGASI</div>
                            <a class="nav-link" href="../home.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Home
                            </a>
                            <a class="nav-link" href="../data_gp/lihat_gp.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Data Guru Pendamping
                            </a>
                            <a class="nav-link" href="../data_juri/lihat_juri.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Data Juri
                            </a>
                            <a class="nav-link" href="../data_kelas/lihat_kelas.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Data Kelas
                            </a>
                            <a class="nav-link" href="../data_kategori/lihat_kategori.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Data Kategori
                            </a>
                            <a class="nav-link" href="../data_kompetisi/lihat_kompetisi.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Data Kompetisi
                            </a>
                            <a class="nav-link" href="index.html">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Data Nilai
                            </a>
                            <a class="nav-link" href="../data_siswa/lihat_siswa.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Data Siswa
                            </a>
                        </div>
                    </div>
                    
