<?php

// koneksi database
include 'koneksi.php';

// menangkap data yang di kirim dari form
$id_kompetisi = mysqli_real_escape_string($koneksi, $_POST['id_kompetisi']);
$no_pes = mysqli_real_escape_string($koneksi, $_POST['no_pes']);
$id_juri = mysqli_real_escape_string($koneksi, $_POST['id_juri']);
$nilai1 = mysqli_real_escape_string($koneksi, $_POST['nilai1']);
$ket_n1 = mysqli_real_escape_string($koneksi, $_POST['ket_n1']);
$nilai2 = mysqli_real_escape_string($koneksi, $_POST['nilai2']);
$ket_n2 = mysqli_real_escape_string($koneksi, $_POST['ket_n2']);
$nilai3 = mysqli_real_escape_string($koneksi, $_POST['nilai3']);
$ket_n3 = mysqli_real_escape_string($koneksi, $_POST['ket_n3']);
$jml_nilai = $nilai1 + $nilai2 + $nilai3;
$tgl_input = date('D/M/Y');
$wkt_input = date('H:i:s');

// menginput data ke database
mysqli_query($koneksi, "INSERT INTO tb_nilai(id_kompetisi, no_pes, id_juri, nilai1, ket_n1, nilai2, ket_n2, nilai3, ket_n3, jml_nilai, tgl_input, wkt_input) VALUES ('$id_kompetisi','$no_pes','$id_juri','$nilai1','$ket_n1','$nilai2','$ket_n2','$nilai3','$ket_n3','$jml_nilai','$tgl_input','$wkt_input')");
echo "<script>alert('Data nilai telah berhasil diinput');window.location='index.php'</script>";
