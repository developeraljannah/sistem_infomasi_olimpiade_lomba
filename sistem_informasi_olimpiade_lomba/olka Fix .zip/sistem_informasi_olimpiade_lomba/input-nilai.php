<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Sistem Informasi Olimpiade, Lomba dan Kompetensi Al Azhar</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
    <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/stylish-portfolio.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Form -->
    <section class="content-section bg-warning">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="card shadow-lg border-0 rounded-lg mt-1">
                        <div class="card-header">
                            <h3 class="text-center font-weight-light my-4">Form Input Nilai</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="simpan-nilai.php">
                                <div class="form-group">
                                    <label>Kompetisi</label>
                                    <select name="id_kompetisi" class="form-control">
                                        <option value="">= Pilih Kompetisi =</option>
                                        <?php
                                        include "koneksi.php";
                                        // melihat isi dari tabel kompetisi
                                        $qrykompetisi = mysqli_query($koneksi, "SELECT * FROM tb_kompetisi");
                                        while ($datakompetisi = mysqli_fetch_array($qrykompetisi)) {
                                            $idkompetisi = $datakompetisi['id_kompetisi'];
                                            $namakompetisi = $datakompetisi['nama_kompetisi'];
                                        ?>
                                            <option value="<?php echo $idkompetisi; ?>"><?php echo $namakompetisi; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Peserta</label>
                                    <select name="no_pes" class="form-control">
                                        <option value="">= Pilih Peserta =</option>
                                        <?php
                                        include "koneksi.php";
                                        // melihat isi dari tabel peserta
                                        $qryregistrasi = mysqli_query($koneksi, "SELECT tb_siswa.nisn, tb_siswa.nama_siswa, tb_registrasi.no_pes FROM tb_siswa, tb_registrasi WHERE tb_siswa.nisn = tb_registrasi.nisn");
                                        while ($dataregistrasi = mysqli_fetch_array($qryregistrasi)) {
                                            $nopes = $dataregistrasi['no_pes'];
                                            $nama_siswa = $dataregistrasi['nama_siswa'];
                                        ?>
                                            <option value="<?php echo $nopes; ?>"><?php echo $nama_siswa; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Juri</label>
                                    <select name="id_juri" class="form-control">
                                        <option value="">= Pilih Juri =</option>
                                        <?php
                                        include "koneksi.php";
                                        // melihat isi dari tabel juri
                                        $qryjuri = mysqli_query($koneksi, "SELECT * FROM tb_juri");
                                        while ($datajuri = mysqli_fetch_array($qryjuri)) {
                                            $idjuri = $datajuri['id_juri'];
                                            $namajuri = $datajuri['nama_juri'];
                                        ?>
                                            <option value="<?php echo $idjuri; ?>"><?php echo $namajuri; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Nilai Ke 1</label>
                                    <input type="text" class="form-control" name="nilai1" placeholder="Ketikkan nilai ke 1" />
                                </div>
                                <div class="form-group">
                                    <label>Keterangan Nilai ke 1</label>
                                    <input type="text" class="form-control" name="ket_n1" placeholder="Ketikkan keterangan nilai 1" />
                                </div>
                                <div class="form-group">
                                    <label>Nilai Ke 2</label>
                                    <input type="text" class="form-control" name="nilai2" placeholder="Ketikkan nilai ke 2" />
                                </div>
                                <div class="form-group">
                                    <label>Keterangan Nilai ke 2</label>
                                    <input type="text" class="form-control" name="ket_n2" placeholder="Ketikkan keterangan nilai 2" />
                                </div>
                                <div class="form-group">
                                    <label>Nilai Ke 3</label>
                                    <input type="text" class="form-control" name="nilai3" placeholder="Ketikkan nilai ke 2" />
                                </div>
                                <div class="form-group">
                                    <label>Keterangan Nilai ke 3</label>
                                    <input type="text" class="form-control" name="ket_n3" placeholder="Ketikkan keterangan nilai 3" />
                                </div>
                                <div class="form-group d-flex align-items-center justify-content-between mt-4 mb-0">
                                    <input type="submit" class="btn btn-primary" name="kirim" value="Kirim">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="overlay"></div>
            </div>
    </section>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/stylish-portfolio.min.js"></script>

</body>

</html>