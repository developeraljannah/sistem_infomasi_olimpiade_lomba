<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Sistem Informasi Olimpiade, Lomba dan Kompetensi Al Azhar</title>

  <!-- Bootstrap Core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom Fonts -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
  <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link href="css/stylish-portfolio.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <?php
  include "navigasi.php";
  ?>

  <!-- Header -->
  <header class="masthead d-flex">
    <div class="container text-center my-auto">
      <h3 class="mb-1">Sistem Informasi Olimpiade, Lomba dan Kompetensi Al Azhar</h3>
      <h5 class="mb-5">
        <em>Sebuah Platform Digital Untuk Mengelola Informasi Olimpiade, Lomba dan Kompetensi Al Azhar</em>
      </h5>
      <a class="btn btn-primary btn-xl js-scroll-trigger" href="#fitur">Selanjutnya</a>
    </div>
    <div class="overlay"></div>
  </header>

  <!-- Fitur -->
  <section class="content-section bg-primary text-white text-center" id="fitur">
    <div class="container">
      <div class="content-section-heading">
        <h1 class="text-secondary mb-0">Fitur</h1>
        <h3 class="mb-5">Di Platform Digital ini anda dapat</h3>
      </div>
      <div class="row">
        <div class="col-lg-4 col-md-6 mb-5 mb-lg-0">
          <span class="service-icon rounded-circle mx-auto mb-3">
            <i class="icon-trophy"></i>
          </span>
          <h4>
            <strong>Kompetisi</strong>
          </h4>
          <p class="text-faded mb-0">Dapat melihat kompetisi yang ada</p>
        </div>
        <div class="col-lg-4 col-md-6 mb-5 mb-lg-0">
          <span class="service-icon rounded-circle mx-auto mb-3">
            <i class="icon-pencil"></i>
          </span>
          <h4>
            <strong>Penilaian</strong>
          </h4>
          <p class="text-faded mb-0">Juri dapat menginput nilai secara online</p>
        </div>
        <div class="col-lg-4 col-md-6 mb-5 mb-md-0">
          <span class="service-icon rounded-circle mx-auto mb-3">
            <i class="icon-lock"></i>
          </span>
          <h4>
            <strong>Keamanan</strong>
          </h4>
          <p class="text-faded mb-0">Bagi juri yang menginput nilai diharuskan login terlebih dahulu</p>
        </div>
      </div>
      <br>
      <a class="btn btn-dark btn-xl js-scroll-trigger" href="#registrasi">Registrasi</a>
    </div>
  </section>

  <!-- Registrasi -->
  <section class="callout" id="registrasi">
    <div class="container text-center">
      <h2 class="mx-auto mb-5">Klik Link dibawah untuk registrasi</h2>
      <a class="btn btn-primary btn-xl" data-toggle="modal" data-target="#ModalRegistrasi">Daftar Peserta Lomba</a>
    </div>
  </section>

  <!-- Modal Form Registrasi -->
  <div class="modal fade" id="ModalRegistrasi" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="ModalRegistrasi">Pendaftaran Peserta Lomba</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="simpan_registrasi.php" method="post">
            <div class="form-group">
              <label>Kompetisi</label>
              <select name="id_kompetisi" class="form-control">
                <option value="">= Pilih Kompetisi =</option>
                <?php
                include "koneksi.php";
                // melihat isi dari tabel kompetisi
                $qrykompetisi = mysqli_query($koneksi, "SELECT * FROM tb_kompetisi");
                while ($datakompetisi = mysqli_fetch_array($qrykompetisi)) {
                  $idkompetisi = $datakompetisi['id_kompetisi'];
                  $namakompetisi = $datakompetisi['nama_kompetisi'];
                ?>
                  <option value="<?php echo $idkompetisi; ?>"><?php echo $namakompetisi; ?></option>
                <?php } ?>
              </select>
            </div>
            <div class="form-group">
              <label>NISN</label>
              <select name="nisn" class="form-control">
                <option value="">= Pilih Siswa =</option>
                <?php
                // melihat isi dari tabel siswa
                $qrysiswa = mysqli_query($koneksi, "SELECT * FROM tb_siswa");
                while ($datasiswa = mysqli_fetch_array($qrysiswa)) {
                  $nisn = $datasiswa['nisn'];
                  $namasiswa = $datasiswa['nama_siswa'];
                ?>
                  <option value="<?php echo $nisn; ?>"><?php echo $namasiswa; ?></option>
                <?php } ?>
              </select>
            </div>
            <div class="form-group">
              <label>Guru Pendamping</label>
              <select name="id_gurupendamping" class="form-control">
                <option value="">= Pilih Guru Pendamping =</option>
                <?php
                // melihat isi dari tabel siswa
                $qrygp = mysqli_query($koneksi, "SELECT * FROM tb_gurupendamping");
                while ($datagp = mysqli_fetch_array($qrygp)) {
                  $idgp = $datagp['id_gurupendamping'];
                  $namagp = $datagp['nama_gp'];
                ?>
                  <option value="<?php echo $idgp; ?>"><?php echo $namagp; ?></option>
                <?php } ?>
              </select>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
          <button type="submit" class="btn btn-primary">Kirim</button>
        </div>
        </form>
      </div>
    </div>
  </div>

  <!-- juri -->
  <section class="content-section bg-success text-white text-center" id="loginjuri">
    <div class="container text-center">
    <h1 class="text-white mb-0">Klik Link dibawah untuk login juri</h1><br>
      <a class="btn btn-dark btn-xl" data-toggle="modal" data-target="#ModalLogin">Login Juri</a>
    </div>
  </section>

  <div class="modal fade" id="ModalLogin" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title" id="ModalLogin" style="margin: 0px auto;">Login Juri</h3>
        </div>
        <div class="modal-body">
          <form action="login-juri.php" method="POST">
            <div class="form-group">
              <label class="small mb-1">Email</label>
              <input class="form-control py-4" type="email" name="email_juri" placeholder="Masukkan Email" />
            </div>
            <div class="form-group">
              <label class="small mb-1">Password</label>
              <input class="form-control py-4" type="password" name="password_juri" placeholder="Masukkan Kata Sandi" />
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
          <input type="submit" name="login" class="btn btn-primary" value="Login">
        </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer text-center">
    <div class="container">
      <ul class="list-inline mb-5">
        <li class="list-inline-item">
          <a class="social-link rounded-circle text-white mr-3" href="#!">
            <i class="icon-social-facebook"></i>
          </a>
        </li>
        <li class="list-inline-item">
          <a class="social-link rounded-circle text-white mr-3" href="#!">
            <i class="icon-social-twitter"></i>
          </a>
        </li>
        <li class="list-inline-item">
          <a class="social-link rounded-circle text-white" href="#!">
            <i class="icon-social-github"></i>
          </a>
        </li>
      </ul>
      <p class="text-muted small mb-0">Copyright &copy; Sistem Informasi Olimpiade, Lomba dan Kompetensi Al Azhar 2013</p>
    </div>
  </footer>

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded js-scroll-trigger" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/stylish-portfolio.min.js"></script>

</body>

</html>